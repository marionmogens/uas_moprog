import 'package:flutter/material.dart';
import '../data/booking_options.dart';
import '../models/booking_draft.dart';
import '../models/padel_court.dart';
import '../services/api_exception.dart';
import '../services/booking_service.dart';
import '../utils/formatters.dart';
import '../widgets/selectable_option.dart';
import 'summary_page.dart';

class SchedulePage extends StatefulWidget {
  final PadelCourt court;
  final String duration;
  final int durationHours; // jumlah slot 1 jam yang WAJIB dipilih
  final List<DraftAddon> addons; // add-on terpilih beserta jumlahnya
  final String note;
  final int courtPrice; // harga sewa lapangan untuk durasi ini

  const SchedulePage({
    super.key,
    required this.court,
    required this.duration,
    required this.durationHours,
    required this.addons,
    required this.note,
    required this.courtPrice,
  });

  @override
  State<SchedulePage> createState() => _SchedulePageState();
}

class _SchedulePageState extends State<SchedulePage> {
  late String _selectedField; // diisi di initState dari daftar lapangan tempat ini
  DateTime? _selectedDate;
  // Slot yang dipilih (bisa lebih dari satu, jumlahnya harus sama
  // dengan durationHours supaya reservasi valid).
  final Set<int> _selectedSlotIndexes = {};
  // Kelas punya sesi jam tetap dan tidak memilih lapangan.
  bool get _isClass => widget.court.category == 'Kelas';

  // Jam yang sudah dipesan orang lain (dari Supabase) untuk lapangan + tanggal
  // yang sedang dipilih. Menggantikan daftar "Penuh" statis sebelumnya.
  Set<int> _takenSlots = {};
  bool _loadingSlots = false;
  String? _slotsError;
  int _slotsToken = 0; // untuk mengabaikan respons lama kalau user ganti pilihan cepat

  // Kunci lapangan yang sama dengan yang disimpan saat checkout
  // (Kelas memakai lokasi kelas, Lapangan memakai "Lapangan 1/2/3").
  String get _fieldKey =>
      _isClass ? BookingService.classFieldKey : _selectedField;

  Future<void> _loadTakenSlots() async {
    final date = _selectedDate;
    final token = ++_slotsToken;
    if (date == null) {
      setState(() {
        _takenSlots = {};
        _loadingSlots = false;
        _slotsError = null;
      });
      return;
    }

    setState(() {
      _loadingSlots = true;
      _slotsError = null;
    });
    try {
      final taken = await BookingService.instance.fetchTakenSlots(
        courtId: widget.court.id,
        fieldName: _fieldKey,
        date: date,
      );
      if (!mounted || token != _slotsToken) return;
      setState(() {
        _takenSlots = taken;
        _loadingSlots = false;
        // jam yang ternyata sudah diambil orang lain dilepas dari pilihan
        _selectedSlotIndexes.removeWhere(taken.contains);
      });
    } on ApiException catch (e) {
      if (!mounted || token != _slotsToken) return;
      setState(() {
        _takenSlots = {};
        _loadingSlots = false;
        _slotsError = e.message;
      });
    }
  }

  // Kelas: memilih satu sesi berarti memilih 2 slot berurutan
  // (slot awal dan slot sesudahnya).
  void _selectClassSession(int startSlot) {
    setState(() {
      _selectedSlotIndexes.clear();
      _selectedSlotIndexes.add(startSlot);
      _selectedSlotIndexes.add(startSlot + 1);
    });
  }

  @override
  void initState() {
    super.initState();
    _selectedField = widget.court.fieldNames.first;
  }

  Future<void> _pickDate() async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate ?? now,
      firstDate: now,
      lastDate: now.add(const Duration(days: 30)),
      helpText: 'Pilih Tanggal Reservasi',
    );
    if (picked != null) {
      setState(() {
        _selectedDate = picked;
        // Kelas: sesinya tetap, jadi tidak perlu direset saat ganti tanggal.
        _selectedSlotIndexes.clear();
      });
      _loadTakenSlots();
    }
  }

  // Buat pesanan dari pilihan user lalu lanjut ke Ringkasan (tanpa keranjang).
  void _continueToSummary() {
    final sorted = _selectedSlotIndexes.toList();
    sorted.sort();
    final draft = BookingDraft(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      court: widget.court,
      fieldName: _isClass ? widget.court.location : _selectedField,
      date: _selectedDate!,
      timeSlot: _formatSlots(sorted),
      slotIndexes: sorted,
      duration: widget.duration,
      addons: widget.addons.map((a) => a.copy()).toList(),
      note: widget.note,
      courtPrice: widget.courtPrice,
    );
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => SummaryPage(draft: draft)),
    );
  }

  // Harga sesi = sewa lapangan + add-on terpilih (untuk ditampilkan di header).
  int get _sessionPrice =>
      widget.courtPrice +
          widget.addons.fold(0, (sum, a) => sum + a.subtotal);

  // Pilih / lepas slot jam. Slot yang dipilih HARUS berurutan.
  // - Ketuk slot yang sudah dipilih: slot itu dilepas.
  // - Ketuk slot baru saat belum ada pilihan: langsung dipilih.
  // - Ketuk slot baru yang menempel di ujung pilihan (jam sebelum atau
  //   sesudahnya) dan jumlahnya masih kurang: ditambahkan.
  // - Selain itu (tidak menempel, atau jumlah sudah pas): pilihan lama
  //   diganti, mulai lagi dari slot yang baru diketuk.
  // Slot penuh tidak bisa diketuk, jadi pilihan tidak mungkin melewati slot penuh.
  void _toggleSlot(int index) {
    if (_selectedSlotIndexes.contains(index)) {
      setState(() => _selectedSlotIndexes.remove(index));
      return;
    }

    if (_selectedSlotIndexes.isEmpty) {
      setState(() => _selectedSlotIndexes.add(index));
      return;
    }

    final sorted = _selectedSlotIndexes.toList();
    sorted.sort();
    final isNextToSelection =
        index == sorted.first - 1 || index == sorted.last + 1;

    setState(() {
      if (isNextToSelection &&
          _selectedSlotIndexes.length < widget.durationHours) {
        _selectedSlotIndexes.add(index);
      } else {
        _selectedSlotIndexes.clear();
        _selectedSlotIndexes.add(index);
      }
    });
  }

  // Mengubah daftar index slot (sudah terurut) jadi teks jam.
  // Jam yang berurutan digabung: 18:00 + 19:00 jadi "18:00 - 20:00".
  String _formatSlots(List<int> sorted) {
    final parts = <String>[];
    int start = sorted.first;
    int prev = sorted.first;
    for (int i = 1; i < sorted.length; i++) {
      if (sorted[i] == prev + 1) {
        prev = sorted[i];
      } else {
        parts.add('${timeSlots[start]} - ${_nextHour(timeSlots[prev])}');
        start = sorted[i];
        prev = sorted[i];
      }
    }
    parts.add('${timeSlots[start]} - ${_nextHour(timeSlots[prev])}');
    return parts.join(', ');
  }

  String get _buttonLabel {
    if (_selectedSlotIndexes.length < widget.durationHours) {
      if (_isClass) return 'Pilih sesi kelas terlebih dahulu';
      return 'Pilih ${widget.durationHours} jam berurutan '
          '(${_selectedSlotIndexes.length}/${widget.durationHours})';
    }
    return 'Lanjut ke Ringkasan';
  }

  String _nextHour(String hour) {
    final h = int.parse(hour.split(':')[0]) + 1;
    return '${h.toString().padLeft(2, '0')}:00';
  }

  @override
  Widget build(BuildContext context) {
    // tombol "Lanjut" hanya aktif kalau tanggal DAN slot sudah dipilih
    final bool canContinue = _selectedDate != null &&
        _selectedSlotIndexes.length == widget.durationHours;

    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        backgroundColor: Colors.pink.shade300,
        title: const Text('Pilih Jadwal',
            style: TextStyle(color: Colors.white, fontSize: 16)),
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(widget.court.name,
                  style: const TextStyle(
                      fontWeight: FontWeight.bold, fontSize: 16)),
              const SizedBox(height: 4),
              Text(
                '${widget.duration} • ${formatRupiah(_sessionPrice)}',
                style: TextStyle(color: Colors.grey.shade600, fontSize: 12),
              ),
              const SizedBox(height: 20),

              if (!_isClass) ...[
                const _SectionTitle('Pilih Lapangan'),
                const SizedBox(height: 10),
                // Dropdown (Spinner): jumlah lapangan berbeda-beda tiap tempat,
                // jadi pilihannya dibuat dari court.fieldNames, bukan angka tetap.
                DropdownButtonFormField<String>(
                  initialValue: _selectedField,
                  isExpanded: true,
                  decoration: InputDecoration(
                    prefixIcon:
                    Icon(Icons.sports_tennis, color: Colors.pink.shade300),
                    filled: true,
                    fillColor: Colors.white,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide(color: Colors.grey.shade300),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide(color: Colors.grey.shade300),
                    ),
                  ),
                  items: widget.court.fieldNames
                      .map((field) => DropdownMenuItem<String>(
                    value: field,
                    child: Text(field),
                  ))
                      .toList(),
                  onChanged: (value) {
                    if (value == null) return;
                    setState(() {
                      _selectedField = value;
                      // slot terpakai beda tiap lapangan,
                      // jadi pilihan lama dikosongkan.
                      _selectedSlotIndexes.clear();
                    });
                    _loadTakenSlots();
                  },
                ),

                const SizedBox(height: 20),
              ],

              const _SectionTitle('Pilih Tanggal'),
              const SizedBox(height: 10),
              InkWell(
                onTap: _pickDate,
                borderRadius: BorderRadius.circular(10),
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(
                      horizontal: 14, vertical: 14),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: Colors.grey.shade300),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.calendar_today_outlined,
                          size: 18, color: Colors.pink.shade300),
                      const SizedBox(width: 10),
                      // Expanded: teks boleh menyusut / terpotong "..."
                      // daripada mendorong Row keluar layar (overflow).
                      Expanded(
                        child: Text(
                          _selectedDate == null
                              ? 'Ketuk untuk memilih tanggal'
                              : formatDate(_selectedDate!),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontSize: 13,
                            color: _selectedDate == null
                                ? Colors.grey.shade500
                                : Colors.black87,
                            fontWeight: _selectedDate == null
                                ? FontWeight.normal
                                : FontWeight.w600,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              if (!_isClass) ...[
                const SizedBox(height: 20),
                const _SectionTitle('Pilih Jam'),
                const SizedBox(height: 6),
                Text(
                  'Jam operasional ${widget.court.openHours}\n'
                      'Wajib pilih ${widget.durationHours} jam berurutan (1 jam per slot) • '
                      'dipilih ${_selectedSlotIndexes.length}/${widget.durationHours}',
                  style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                ),
                const SizedBox(height: 8),
                _buildLegend(),
                _buildSlotsStatus(),
                const SizedBox(height: 10),
                _buildTimeSlotGrid(),
              ] else ...[
                const SizedBox(height: 20),
                const _SectionTitle('Pilih Sesi Kelas'),
                const SizedBox(height: 6),
                Text(
                  'Setiap sesi berlangsung 2 jam',
                  style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                ),
                const SizedBox(height: 10),
                _buildSlotsStatus(),
                _buildClassSessions(),
              ],
            ],
          ),
        ),
      ),
      bottomNavigationBar: SafeArea(
        top: false,
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.08),
                blurRadius: 10,
                offset: const Offset(0, -2),
              ),
            ],
          ),
          child: SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              // "if" di sini yang nentuin tombol aktif/nonaktif:
              // kalau canContinue false, onPressed diisi null (disabled).
              onPressed: canContinue ? _continueToSummary : null,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.pink.shade300,
                foregroundColor: Colors.white,
                disabledBackgroundColor: Colors.grey.shade300,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              child: Text(_buttonLabel),
            ),
          ),
        ),
      ),
    );
  }

  // Keterangan kecil saat jam terpakai belum dipilih tanggalnya / sedang
  // dimuat / gagal dimuat.
  Widget _buildSlotsStatus() {
    if (_selectedDate == null) {
      return Padding(
        padding: const EdgeInsets.only(top: 8),
        child: Text('Pilih tanggal dulu untuk melihat jam yang tersedia.',
            style: TextStyle(fontSize: 12, color: Colors.grey.shade600)),
      );
    }
    if (_loadingSlots) {
      return const Padding(
        padding: EdgeInsets.only(top: 8),
        child: Row(
          children: [
            SizedBox(
              width: 14,
              height: 14,
              child: CircularProgressIndicator(strokeWidth: 2),
            ),
            SizedBox(width: 8),
            Text('Memeriksa jam yang tersedia...',
                style: TextStyle(fontSize: 12)),
          ],
        ),
      );
    }
    if (_slotsError != null) {
      return Padding(
        padding: const EdgeInsets.only(top: 8),
        child: Wrap(
          crossAxisAlignment: WrapCrossAlignment.center,
          spacing: 8,
          children: [
            Text(_slotsError!,
                style: TextStyle(fontSize: 12, color: Colors.red.shade400)),
            TextButton(
              onPressed: _loadTakenSlots,
              child: const Text('Coba lagi'),
            ),
          ],
        ),
      );
    }
    return const SizedBox.shrink();
  }

  Widget _buildLegend() {
    return Wrap(
      spacing: 14,
      runSpacing: 4,
      children: [
        _legendDot(Colors.white, 'Tersedia', bordered: true),
        _legendDot(Colors.pink.shade300, 'Dipilih'),
        _legendDot(Colors.grey.shade300, 'Penuh'),
      ],
    );
  }

  // Daftar sesi kelas: tiap sesi satu kartu pilihan (SelectableOption).
  // Sesi terpilih kalau kedua slot jamnya ada di _selectedSlotIndexes.
  Widget _buildClassSessions() {
    return Column(
      children: widget.court.classStartSlots.map((start) {
        final isSelected = _selectedSlotIndexes.contains(start) &&
            _selectedSlotIndexes.contains(start + 1);
        final label = '${timeSlots[start]} - ${_nextHour(timeSlots[start + 1])}';
        final isTaken =
            _takenSlots.contains(start) || _takenSlots.contains(start + 1);
        return Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: SizedBox(
            width: double.infinity,
            child: SelectableOption(
              selected: isSelected,
              onTap: isTaken
                  ? () {}
                  : () => _selectClassSession(start),
              child: Row(
                children: [
                  Icon(
                    Icons.schedule,
                    size: 18,
                    color: isSelected ? Colors.pink.shade300 : Colors.grey,
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      isTaken ? '$label • Penuh' : '$label (2 jam)',
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: isTaken ? Colors.grey : Colors.black87,
                      ),
                    ),
                  ),
                  if (isSelected)
                    Icon(Icons.check_circle,
                        color: Colors.pink.shade300, size: 20),
                ],
              ),
            ),
          ),
        );
      }).toList(),
    );
  }

  Widget _legendDot(Color color, String label, {bool bordered = false}) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 10,
          height: 10,
          decoration: BoxDecoration(
            color: color,
            shape: BoxShape.circle,
            border: bordered ? Border.all(color: Colors.grey.shade400) : null,
          ),
        ),
        const SizedBox(width: 4),
        Text(label, style: TextStyle(fontSize: 11, color: Colors.grey.shade600)),
      ],
    );
  }

  // Grid slot jam: disusun manual pakai Wrap + "for" (lewat List.generate)
  // supaya tiap slot bisa dikasih warna berbeda sesuai 3 status:
  // tersedia (putih+border), dipilih (pink), penuh (abu+label "Penuh").
  Widget _buildTimeSlotGrid() {
    return Wrap(
      spacing: 10,
      runSpacing: 10,
      // hanya slot di dalam jam operasional tempat ini yang ditampilkan
      children: List.generate(
          widget.court.closeSlotIndex - widget.court.openSlotIndex, (i) {
        final index = widget.court.openSlotIndex + i;
        final isBooked = _takenSlots.contains(index);
        final isSelected = _selectedSlotIndexes.contains(index);

        Color backgroundColor;
        Color textColor;
        Color borderColor;
        if (isBooked) {
          backgroundColor = Colors.grey.shade200;
          textColor = Colors.grey.shade500;
          borderColor = Colors.grey.shade200;
        } else if (isSelected) {
          backgroundColor = Colors.pink.shade300;
          textColor = Colors.white;
          borderColor = Colors.pink.shade300;
        } else {
          backgroundColor = Colors.white;
          textColor = Colors.black87;
          borderColor = Colors.grey.shade300;
        }

        return InkWell(
          onTap: isBooked
              ? null // slot penuh tidak bisa ditekan
              : () => _toggleSlot(index),
          borderRadius: BorderRadius.circular(8),
          child: Container(
            width: 72,
            padding: const EdgeInsets.symmetric(vertical: 10),
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: backgroundColor,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: borderColor),
            ),
            // Stack dipakai supaya label "Penuh" bisa ditempel
            // sebagai badge kecil di atas teks jam, tanpa widget
            // tambahan di luar area slot ini.
            child: Stack(
              clipBehavior: Clip.none,
              alignment: Alignment.center,
              children: [
                Text(
                  timeSlots[index],
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: textColor,
                  ),
                ),
                if (isBooked)
                  Positioned(
                    top: -16,
                    child: Text(
                      'Penuh',
                      style: TextStyle(
                        fontSize: 9,
                        color: Colors.red.shade400,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
              ],
            ),
          ),
        );
      }),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String text;
  const _SectionTitle(this.text);

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
    );
  }
}